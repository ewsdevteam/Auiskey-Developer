@extends('admin::layouts.content')

@section('page_title')
    {{ __('admin::app.blog.blogs.title') }}
@stop
@push('scripts')
    
    <script type = "text/javascript">
    $(document).ready(function(){
    
        $('.search-filter').hide();
    })
    

    </script>
@endpush
@section('content')
    <div class="content" style="height: 100%;">
        <?php $locale = request()->get('locale') ?: null; ?>
        <?php $channel = request()->get('channel') ?: null; ?>
        <div class="page-header">
            <div class="page-title">
                <h1>{{ __('admin::app.blog.blogs.title') }}</h1>
            </div>

            <div class="page-action">
            
                <a href="{{ route('admin.blog.blogs.create') }}" class="btn btn-lg btn-primary">
                    {{ __('admin::app.blog.blogs.add-blog-btn-title') }}
                </a>
            </div>
        </div>



        <div class="page-content">
            @inject('blogs', 'Webkul\Admin\DataGrids\BlogDataGrid')
            {!! $blogs->render() !!}
        </div>


    </div>

@stop

